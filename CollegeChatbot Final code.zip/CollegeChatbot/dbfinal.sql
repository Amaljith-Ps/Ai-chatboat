/*
SQLyog Community Edition- MySQL GUI v8.03 
MySQL - 5.5.20-log : Database - chat_bot
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`chat_bot` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `chat_bot`;

/*Table structure for table `chatbot` */

DROP TABLE IF EXISTS `chatbot`;

CREATE TABLE `chatbot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `questions` text NOT NULL,
  `uid` int(11) NOT NULL,
  `answer` text NOT NULL,
  `date` varchar(20) NOT NULL,
  `type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=latin1;

/*Data for the table `chatbot` */

insert  into `chatbot`(`id`,`questions`,`uid`,`answer`,`date`,`type`) values (19,'hi',2,'Hello! How can I assist you today? please enter your id!','2023-08-16','t'),(20,'who is the pm of india',6,'The Prime Minister of India is Narendra Modi.','2023-08-16','t'),(21,'who is the president of america',6,'Joe Biden is the 46th President of the United States.','2023-08-16','t'),(22,'latest car model in india',6,'The latest car model in India is the 2020 Maruti Suzuki Ertiga. It is a 7-seater multipurpose vehicle that is ideal for large families. It features a power-packed engine, top-notch safety features, and a modern interior. It is expensive and comes in various trim levels. Other popular car models in India include the Hyundai Creta, Hyundai Verna, Kia Seltos, and Honda City.','2023-08-16','t'),(23,'national flower',6,'plaza florist\n\nNational Flower Plaza Florist is a family-owned business located in the heart of the Las Vegas Valley providing exceptional custom flower arrangements to bring beauty and elegance to any event. With over 25 years of experience, we proudly serve local and national customers with the best quality blooms and services at an affordable price. Our experienced floral designers are committed to providing the highest level of artistry and service to each and every customer. Our focus is on fresh and long-lasting flowers. From weddings and birthdays to anniversaries and funerals—we bring detailed brilliance to every occasion.','2023-08-16','t'),(24,'national flower of india',6,'The lotus (Nelumbo Nucifera) is India’s national flower. The lotus has long been an important symbol in Hindu mythology, and it is a common motif in Indian art and literature. The lotus is considered a symbol of divine beauty and purity, as its leaves remain untouched by its surroundings, while it grows from the mud of an imperfect world into something pure and perfect.','2023-08-16','t'),(25,'who is naveen',6,'Naveen is an Indian name meaning \"new\". It is a popular name amongst Hindu and Sikh communities. Naveen is also a popular given name among South-east Asian countries like Bangladesh, Malaysia, Singapore, and Indonesia. It can be used as either a given name or surname.','2023-08-16','t'),(26,'who is devika',6,'Devika is an actress and model from India who has starred in Bollywood films, Tamil films, and American television series. She is best known for her roles as Maithili in Jai Santoshi Maa and Saloni in the television series Sajan Re Jhoot Mat Bolo.','2023-08-16','t'),(27,'meaning of devika',6,'Devika is a Hindu female name that means \"little goddess.\" It is derived from the Sanskrit word Divya, which means \"heavenly or divine.\"','2023-08-16','t'),(28,'what is the meaning of athira',6,'CWATscs006','2023-08-16','t'),(29,'hi',6,'Hello! How can I assist you today? please enter your id!','2023-08-16','t'),(30,'what is the meaning of athira',6,'CWATscs006','2023-08-16','t'),(31,'who is tha father of thor',6,'Odin is the father of Thor in Norse mythology.','2023-08-16','t'),(32,'who is thor',6,'Thor is a fictional superhero appearing in American comic books published by Marvel Comics. He is the Asgardian God of Thunder and the crown prince of Asgard, based on the Norse deity of the same name. Thor uses his enchanted hammer, Mjolnir, to fight evil throughout the Nine Realms and other galaxies.','2023-08-16','t'),(33,'what is the meaning of akhila',6,'CWATscs006','2023-08-16','t'),(34,'what is the meaning of devika',6,'CWATscs006','2023-08-16','t'),(35,'meaning of athira',6,'?\n\nAthira is a Hindu/Sanskrit name meaning \"king\" or \"lord of the Earth.\" It is also used to refer to the seventh day of the Hindu lunar week.','2023-08-16','t'),(36,'what is the meaning of devika',6,'Devika is an Indian name meaning \"little girl\". It is derived from a Sanskrit word meaning \"light\" or \"shining\".','2023-08-16','t'),(37,'what is the meaning of akhila',6,'Akhila is a Sanskrit word that means \'complete, entire, or all\'. It is most often used to describe something that is whole, encompassing, or all-inclusive.','2023-08-16','t'),(38,'what is my register number',6,'Your register number will depend on your school or institution. If you are unable to find your register number, please contact your school for more information.','2023-08-16','t'),(39,'what is my registration number',6,'CWATscs006','2023-08-16','t'),(40,'what is my regno',6,'Your registration number cannot be disclosed here as it is a confidential piece of information.','2023-08-16','t'),(41,'what is my register no',6,'CWATscs006','2023-08-16','t'),(42,'what is the meaning of reshma',6,'Reshma is a name derived from Sanskrit, meaning \"ray of light.\" It can also be spelled Raisha. The name is commonly found in India and is particularly popular among Muslim families.','2023-08-16','t'),(43,'hai',2,'kara bonjor\n\nKonnichiwa! Ogenki desuka? Wa, watashi wa, hai, hai kara yo!','2023-08-25','t'),(59,' how to get direction to Food Village',4,'https://maps.app.goo.gl/wKi6fRRWDNVrQRWM9?g_st=iw','2023-08-28','l'),(60,'get directions direction to Surgery',4,'https://maps.app.goo.gl/MbY4sVa58CHsxLA5A?g_st=iw','2023-08-28','l'),(61,'how to get direction to  Univercity',4,'https://maps.app.goo.gl/fz1P8bxJY3Wn98WP7?g_st=iw','2023-08-28','l'),(108,'hello',7,' Hello! How can I help you? If you have any questions or need information, feel free to ask.','2023-09-19','t'),(109,'my mark',7,'Object Oriented programming 90\nDatabase System & Design 88\nComputer networks 90\n','2023-09-19','m'),(110,'time table',7,'Pastel_Floral_Themed_School_Timetable_-_Made_with_PosterMyWall.jpg','2023-09-19','p'),(111,'my registration no',7,'P2747421','2023-09-19','t'),(112,'get me direction to food village',7,'https://maps.app.goo.gl/wKi6fRRWDNVrQRWM9?g_st=iw','2023-09-19','l'),(113,'who is the prime minster of india',7,'The current Prime Minister of India is Narendra Modi.','2023-09-19','t'),(114,'today\'s weather condition of lesister',7,'is cloudy\n\nLesister is currently experiencing cloudy weather conditions. The temperature is around 65°F (18°C), and there is a moderate wind from the southwest at 8mph (13km/h). Skies are overcast, and there is a chance of showers throughout the day.','2023-09-19','t'),(115,'my current location',7,'Assuming you are referring to your physical location, your most accurate answer will depend on your access to specific technology. For example, some smartphones are able to access your GPS coordinates, and some apps provide an estimated location.','2023-09-19','t'),(116,'todays news\r\n',7,'Today\'s news includes a variety of stories from around the world. Reports indicate that the COVID-19 pandemic has claimed more than 1 million lives globally, while the U.S. death toll has surpassed 200,000. Meanwhile, on the economic front, the stock market has posted gains, and the U.S. Treasury is preparing to issue a new bond that could make it easier for U.S. companies to borrow money. In world politics, tensions remain high between the United States and China, with news of sanctions, military maneuvers, and diplomatic standoffs. On the sports front, the NBA finals are underway, while the U.S. Open begins this week. Finally, in entertainment news, a new Star Wars movie will be released soon.','2023-09-19','t'),(117,'today\'s gold rate\r\n',7,'The current gold rate in the United States today is $1,941.90 per troy ounce, according to goldcurrencies.com. Rates may vary depending on where and how you purchase the gold.','2023-09-19','t'),(118,'new notification',7,'2023-09-07 SUMMER VECATION IS GOING TO OVER. CLASS WILL REOPEN AT SEP 3.\n','2023-09-19','t');

/*Table structure for table `college` */

DROP TABLE IF EXISTS `college`;

CREATE TABLE `college` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `place` varchar(500) DEFAULT NULL,
  `post` varchar(500) DEFAULT NULL,
  `email` varchar(500) DEFAULT NULL,
  `phone` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `college` */

insert  into `college`(`id`,`name`,`place`,`post`,`email`,`phone`) values (1,'DE MONFORT UNIVERSITY','LESISTER','le39bh','demonfort@gmail.com',7452634512);

/*Table structure for table `course` */

DROP TABLE IF EXISTS `course`;

CREATE TABLE `course` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `did` int(11) DEFAULT NULL,
  `c_name` varchar(20) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `course` */

insert  into `course`(`cid`,`did`,`c_name`,`description`) values (2,2,'MSC COMPUTING','The MSc in Computer Science program is designed to provide advanced knowledge and skills in the fiel'),(3,3,'PROJECT MANAGEMENET','A Project Management program offers comprehensive insights into the principles and practices of effi');

/*Table structure for table `dataset` */

DROP TABLE IF EXISTS `dataset`;

CREATE TABLE `dataset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `questions` text,
  `answers` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

/*Data for the table `dataset` */

insert  into `dataset`(`id`,`questions`,`answers`) values (3,'hi','Hello! How can I assist you today? please enter your id!'),(4,'Hello',' Hello! How can I help you? If you have any questions or need information, feel free to ask.'),(5,' How can I apply to your college?','You can apply online through our college website. The application process typically involves submitting personal information, academic records, test scores, and any additional documents required for your chosen program.'),(6,' What majors and programs does your college offer?','We offer a wide range of majors and programs across various disciplines, including Arts, Science, Engineering, Business, and more. You can find a comprehensive list of available programs on our college website.'),(7,'What are the tuition fees and financial aid options?',' Tuition fees vary depending on the program and whether you are an in-state or out-of-state student. We offer various financial aid options, including scholarships, grants, and loans. To learn more about financial aid, visit our Financial Aid Office or check our website.'),(8,'how are you','As an AI language model, I don\'t have feelings or emotions, but I\'m here and ready to assist you with any questions or information you may need. How can I help you today?'),(9,'time table','tt'),(10,'mark','mark'),(11,'registration number regno','regno'),(12,'regno','regno'),(13,'register number','regno'),(14,'register no','regno'),(15,'get directions direction to Surgery','link:-Surgery'),(16,'get directions direction to Food Village','link:-Food Village'),(17,'notification notifications','noti'),(18,'get directions direction to Gateway House','link:-Gateway House'),(19,'get directions direction to Hall','link:-Hall'),(20,'get directions direction to Students Union','link:-Students Union'),(21,'get directions direction to Visitor Car Park','link:-Visitor Car Park'),(22,'get directions direction to University','link:-University');

/*Table structure for table `department` */

DROP TABLE IF EXISTS `department`;

CREATE TABLE `department` (
  `did` int(11) NOT NULL AUTO_INCREMENT,
  `dept_name` varchar(20) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`did`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `department` */

insert  into `department`(`did`,`dept_name`,`description`) values (2,'COMPUTER SCIENCE','The Computer Science Department is a dynamic and innovative academic unit within an educational institution, dedicated to the study, research, and advancement of computer science and its related disciplines. This department serves as a hub for students, faculty members, researchers, and industry professionals who share a common interest in understanding and exploring the intricacies of computing technology and its applications.'),(3,'ENGINEERING MANAGEME','The Engineering Management Department is a forward-looking academic division within an institution, dedicated to bridging the gap between engineering and business disciplines. This department focuses on equipping students with the skills and knowledge needed to effectively lead and manage technical projects, teams, and organizations.'),(4,'MEDIA AND COMMUNICAT','The Media and Communication Department is a vibrant academic entity within an institution, dedicated to the exploration and understanding of various forms of media, communication technologies, and their societal impact. This department focuses on preparing students to navigate the dynamic world of media, journalism, public relations, and digital communication.');

/*Table structure for table `facilities` */

DROP TABLE IF EXISTS `facilities`;

CREATE TABLE `facilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `facility` text,
  `des` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `facilities` */

insert  into `facilities`(`id`,`facility`,`des`) values (2,'Computer Labs',' Facilities with computers and software for students to access digital resources, conduct research, complete assignments, and develop technical skills.'),(3,'Libraries',' Collections of books, digital resources, journals, and other materials that support research, learning, and intellectual exploration.'),(4,'Laboratories',' Specialized rooms equipped with equipment and materials for hands-on scientific research, experiments, and practical learning in fields such as chemistry, biology, physics, and engineering.');

/*Table structure for table `locations` */

DROP TABLE IF EXISTS `locations`;

CREATE TABLE `locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `place` varchar(500) DEFAULT NULL,
  `link` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `locations` */

insert  into `locations`(`id`,`place`,`link`) values (1,'Surgery','https://maps.app.goo.gl/MbY4sVa58CHsxLA5A?g_st=iw'),(2,'Food Village','https://maps.app.goo.gl/wKi6fRRWDNVrQRWM9?g_st=iw'),(3,'University','https://maps.app.goo.gl/kvdBQFWPxsDFSFYP7?g_st=iw'),(4,'Gateway House','https://maps.app.goo.gl/qcvk7cuEiYCkFBMS8?g_st=iw'),(5,'Hall','https://maps.app.goo.gl/fz1P8bxJY3Wn98WP7?g_st=iw'),(6,'Students Union','https://maps.app.goo.gl/ozEshEsQw7zZZzpE9?g_st=iw'),(7,'Visitor Car Park','https://maps.app.goo.gl/xzBqb7UPfb4w4g7k7?g_st=iw');

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `l_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `type` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`l_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `login` */

insert  into `login`(`l_id`,`user_name`,`password`,`type`) values (1,'admin','admin','admin'),(2,'amal','123','user'),(3,'amalk','123456','user'),(4,'amalk','1234','user'),(5,'indhu','Indhu@123','user'),(6,'Arun','Arun@1234','user'),(7,'AMALJITH PS','Amaljith@1232','user');

/*Table structure for table `mark` */

DROP TABLE IF EXISTS `mark`;

CREATE TABLE `mark` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) DEFAULT NULL,
  `sub_id` varchar(100) DEFAULT NULL,
  `mark` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `mark` */

insert  into `mark`(`id`,`sid`,`sub_id`,`mark`) values (3,4,'2','89'),(4,4,'3','78'),(6,7,'5','90'),(7,7,'6','88'),(8,7,'7','90');

/*Table structure for table `notification` */

DROP TABLE IF EXISTS `notification`;

CREATE TABLE `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notification` varchar(500) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `notification` */

insert  into `notification`(`id`,`notification`,`date`) values (4,'SUMMER VECATION IS GOING TO OVER. CLASS WILL REOPEN AT SEP 3.','2023-09-07');

/*Table structure for table `registration_no` */

DROP TABLE IF EXISTS `registration_no`;

CREATE TABLE `registration_no` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `registration_no` */

insert  into `registration_no`(`id`,`no`) values (2,'P2747421'),(3,'P2747423'),(4,'P2747424'),(5,'P2747425'),(6,'P2747426');

/*Table structure for table `subject` */

DROP TABLE IF EXISTS `subject`;

CREATE TABLE `subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `subject` */

insert  into `subject`(`id`,`cid`,`subject`,`date`) values (3,1,'python','2023-08-09'),(4,2,'CS','2023-09-07'),(5,2,'Object Oriented programming','2023-09-07'),(6,2,'Database System & Design','2023-09-07'),(7,2,'Computer networks','2023-09-07');

/*Table structure for table `timetable` */

DROP TABLE IF EXISTS `timetable`;

CREATE TABLE `timetable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course` int(11) DEFAULT NULL,
  `sem` int(11) DEFAULT NULL,
  `timetable` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `timetable` */

insert  into `timetable`(`id`,`course`,`sem`,`timetable`) values (1,1,1,'OIP.jpg'),(3,3,1,'WhatsApp_Image_2023-08-28_at_11.40.19.jpg'),(4,2,1,'Pastel_Floral_Themed_School_Timetable_-_Made_with_PosterMyWall.jpg');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `fname` varchar(100) DEFAULT NULL,
  `lname` varchar(100) DEFAULT NULL,
  `place` varchar(100) DEFAULT NULL,
  `post` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` bigint(20) DEFAULT NULL,
  `Register_no` varchar(100) DEFAULT NULL,
  `sem` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`id`,`lid`,`cid`,`fname`,`lname`,`place`,`post`,`email`,`phone`,`Register_no`,`sem`) values (2,4,1,'Amal','kumar','guruvayoor','kunnamkulam','amal@gmail.com',9876504312,'Cwdrt 30065',1),(3,5,1,'Kalindhi','krishna','malappuram','malappuram 81','kalindhi@gmail.com',9087654123,'Cwdrt 30064',1),(4,6,1,'Arun','kumar','guruvayoor','guruvayoor','arun@gmail.com',9876504312,'CWATscs006',1),(5,7,2,'AMALJITH','SAJI','PRESTON','PR11JB','amaljithsaji0@gmail.com',7452634512,'P2747421',1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
