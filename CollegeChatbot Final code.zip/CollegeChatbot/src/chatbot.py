import numpy as np
import pymysql

from werkzeug.utils import secure_filename
import re, math

from src.dbconnection import *

import openai

# Replace 'your-api-key' with your actual OpenAI API key
openai.api_key = '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'

def chat_with_bot(prompt):
    response = openai.Completion.create(
        engine="text-davinci-003",  # You can use "davinci" or other available engines
        prompt=prompt,
        max_tokens=500  # Maximum length of the response
    )
    return response.choices[0].text.strip()

# while True:
#     user_input = input("You: ")
#     if user_input.lower() in ['bye', 'exit', 'quit']:
#         print("Chatbot: Goodbye! Have a great day!")
#         break
#     chat_response = chat_with_bot(user_input)
#     print("Chatbot:", chat_response)
def cb(qus):
    qus=qus.lower()
    WORD = re.compile(r'\w+')

    from collections import Counter
    def text_to_vector(text):
        words = WORD.findall(text)
        return Counter(words)

    def get_cosine(vec1, vec2):
        intersection = set(vec1.keys()) & set(vec2.keys())
        numerator = sum([vec1[x] * vec2[x] for x in intersection])
        sum1 = sum([vec1[x] ** 2 for x in vec1.keys()])
        sum2 = sum([vec2[x] ** 2 for x in vec2.keys()])
        denominator = math.sqrt(sum1) * math.sqrt(sum2)

        if not denominator:
            return 0.0
        else:
            return float(numerator) / denominator

    vector1 = text_to_vector(qus)
    qry="select questions,id from dataset"
    ss1 =selectall(qry)

    print("s--" ,ss1)
    res = []
    for d in ss1:
        vector2 = text_to_vector(str(d['questions']).lower())
        cosine = get_cosine(vector1, vector2)
        # print("cosine",cosine)

        res.append(cosine)

    print("res---" ,res)

    ss = 0
    cnt = -1
    i = 0
    for s in res:
        if s > 0.3:
            if ss <= float(s):
                cnt = i
                ss = s
        i = i + 1

    print("ss", ss)
    print("cnt", cnt)
    if cnt!=-1:
        q="select * from dataset where id=%s"
        aa = selectone(q,str(ss1[cnt]['id']))
        print(aa)
        if aa is None:
            chat_response = chat_with_bot(qus)
            return chat_response
        else:
            return aa['answers']
    else:
        chat_response = chat_with_bot(qus)
        return chat_response


# cb("How are you?")