import functools
import os
from tkinter import WORD
import re

from flask import *
from werkzeug.utils import secure_filename
from src.dbconnection import *
from src.chatbot import *
obj=Flask(__name__)
obj.secret_key="abc"




def login_required(func):
    @functools.wraps(func)
    def secure_function():
        if "lid" not in session:
            return render_template('login.html')
        return func()
    return secure_function


@obj.route('/logout')
@login_required
def logout():
    session.clear()
    return redirect('/')


@obj.route('/')
def main():
    return render_template('login.html')

@obj.route('/login_post',methods=['get','post'])

def login_post():
    uname=request.form['un']
    pwd=request.form['pwd']
    qry="SELECT * FROM login WHERE `user_name`=%s AND `password`=%s "
    val=(uname,pwd)
    res=selectone(qry,val)
    if res is None:
        return '''<script>alert("invalid username or password");window.location="/"</script>'''
    elif res['type']=='admin':
        session['lid']=res['l_id']

        return '''<script>alert("welcome");window.location="/Admin_homepage"</script>'''
    elif res['type']=='user':
        session['lid']=res['l_id']
        return '''<script>alert("welcome");window.location="/user_homepage"</script>'''
    else:
        return '''<script>alert("invalid user");window.location="/"</script>'''














# ///////////////////////////////////////////////

@obj.route('/Deptview',methods=['get','post'])
@login_required

def Deptview():
    qry="SELECT * FROM `department`"
    res=selectall(qry)
    return render_template('Dept view.html',val=res)


@obj.route('/Registeration',methods=['post'])
@login_required


def Registeration():
    return render_template('Registeration.html')


@obj.route('/Registeration1',methods=['post'])
@login_required


def Registeration1():
    dname = request.form['dname']
    desc = request.form['desc']
    qry="INSERT INTO `department` VALUES(NULL,%s,%s)"
    val=(dname,desc)
    iud(qry,val)
    return '''<script>alert("Added successfully");window.location="/Deptview"</script>'''


@obj.route('/Dept_edit',methods=['get','post'])
@login_required

def Dept_edit():
    id=request.args.get('did')
    print (id)
    session['dept_id']=id
    qry="SELECT * FROM `department` WHERE `did`= %s"
    res=selectone(qry,id)
    print (res,"FFFFFFFFFFFFFFFFFFFFFFFFFF")

    return render_template('Dept_edit.html',val=res)

@obj.route('/Dept_edit1',methods=['post'])
@login_required
def Dept_edit1():
    dname = request.form['textfield']
    desc = request.form['textarea2']
    qry="UPDATE `department` SET `dept_name`=%s ,`description`=%s WHERE `did`=%s"
    val=(dname,desc,session['dept_id'])
    iud(qry,val)
    return '''<script>alert("Update successfully");window.location="/Deptview"</script>'''


@obj.route('/delete_dept',methods=['get','post'])
@login_required

def delete_dept():
    id=request.args.get('did')
    qry="DELETE FROM `department` WHERE `did`=%s"
    iud(qry,id)
    return '''<script>alert("Deleted successfully");window.location="/Deptview"</script>'''






@obj.route('/Courseview',methods=['post','get'])
@login_required


def Courseview():
    qry="SELECT course.*,department.dept_name FROM `course` JOIN `department` ON `department`.`did`=`course`.`did`"
    res=selectall(qry)

    return render_template('Course view.html',val=res)


@obj.route('/course_add', methods=['get', 'post'])
@login_required

def course_add():
    qry="SELECT * FROM `department`"
    res=selectall(qry)
    return render_template('course_add.html',val=res)


@obj.route('/course_add1', methods=['get', 'post'])
@login_required

def course_add1():
    dep = request.form['dep']

    cname = request.form['crs']
    desc = request.form['des']
    qry="INSERT INTO `course` VALUES(NULL,%s,%s,%s)"
    val=(dep,cname,desc)
    iud(qry,val)
    return '''<script>alert("Added successfully");window.location="/Courseview"</script>'''


@obj.route('/delete_course',methods=['get','post'])
@login_required

def delete_course():
    id=request.args.get('id')
    qry="DELETE FROM `course` WHERE `cid`=%s"
    iud(qry,id)
    return '''<script>alert("Deleted successfully");window.location="/Courseview"</script>'''


@obj.route('/delete_no',methods=['get','post'])
@login_required

def delete_no():
    id=request.args.get('did')
    qry="DELETE FROM `registration_no` WHERE `id`=%s"
    iud(qry,id)
    return '''<script>alert("Deleted successfully");window.location="/view_registration_no"</script>'''






@obj.route('/view_registration_no',methods=['get','post'])
@login_required

def view_registration_no():
    qry="SELECT * FROM `registration_no`"
    res=selectall(qry)
    return render_template('view_registration_no.html',val=res)



@obj.route('/add_reg_no',methods=['post','get'])
def add_reg_no():
    return render_template('add_reg_no.html')

@obj.route('/add_reg_no1',methods=['post','get'])

def add_reg_no1():
    no=request.form['tx1']
    qry="insert into registration_no values(null,%s)"
    val=(no)
    iud(qry,val)
    return '''<script>alert("Added successfully");window.location="/view_registration_no"</script>'''





@obj.route('/clg',methods=['post','get'])
@login_required

def clg():
    qry="select * from college where id=%s"
    res=selectone(qry,1)
    print (res,"JJJJJJJJJJJJJJJJJJ")

    return render_template('college.html',val=res)

@obj.route('/clg_1',methods=['post','get'])
@login_required

def clg_1():
    qry="SELECT * FROM `college` where id=%s"
    res=selectone(qry,1)
    print (res,"YYYYYYYYYYYYYYYYYYYYYY")
    if res is None:
        print (request.form,"KKKKKKKKKKKKKKKKKK")
        cname = request.form['tx1']
        place = request.form['tx2']
        post = request.form['tx3']
        # pin = request.form['tx4']
        email = request.form['tx5']
        phone = request.form['tx6']
        qry="INSERT INTO `college` VALUES(NULL,%s,%s,%s,%s,%s)"
        val=(cname,place,post,email,phone)
        iud(qry,val)
        return '''<script>alert("Added successfully");window.location="/clg"</script>'''
    else:
        cname = request.form['tx1']
        place = request.form['tx2']
        post = request.form['tx3']
        email = request.form['tx5']
        phone = request.form['tx6']
        qry="UPDATE `college` SET `name`=%s,`place`=%s,`post`=%s,`email`=%s,`phone`=%s WHERE `id`=1"
        val=(cname,place,post,email,phone)
        iud(qry,val)
        return '''<script>alert("update successfully");window.location="/clg"</script>'''





@obj.route('/Admin_homepage',methods=['post','get'])
@login_required


def Admin_homepage():
    return render_template('Admin_homepage.html')




# /////////////////////////////////////













@obj.route('/quest_ans11',methods=['post','get'])
@login_required


def quest_ans11():
    qry="select * from dataset"
    res=selectall(qry)

    return render_template('viewqstns.html',val=res)



@obj.route('/quest_ans',methods=['post','get'])
def quest_ans():
    return render_template('queston_ans.html')

@obj.route('/quest_ans1',methods=['post','get'])

def quest_ans1():
    qn=request.form['textfield']
    ans=request.form['textfield2']
    qry="insert into dataset values(null,%s,%s)"
    val=(qn,ans)
    iud(qry,val)
    return '''<script>alert("Added successfully");window.location="/quest_ans11"</script>'''




@obj.route('/delete_dataset',methods=['post','get'])
@login_required

def delete_dataset():

    id=request.args.get('id')
    qry="DELETE FROM `dataset` WHERE id=%s"
    iud(qry,id)
    return '''<script>alert("Delete  successfully");window.location="/quest_ans11"</script>'''
@obj.route('/facview',methods=['post','get'])
@login_required
def facview():
    qry="SELECT * FROM `facilities` "
    res=selectall(qry)
    return render_template('facview.html',val=res)


@obj.route('/fac',methods=['post'])
@login_required
def fac():
    return render_template('addfac.html')


@obj.route('/fac1',methods=['post'])
@login_required


def fac1():
    fname = request.form['tx1']
    dtl = request.form['tx2']
    qry="INSERT INTO `facilities` VALUES(NULL,%s,%s)"
    val=(fname,dtl)
    iud(qry,val)
    return '''<script>alert("Added successfully");window.location="/facview"</script>'''


@obj.route('/fac_edit',methods=['get','post'])
@login_required
def fac_edit():
    id=request.args.get('id')
    session['Fi_d']=id
    qry="select * from facilities where id=%s"
    res=selectone(qry,id)


    return render_template('fac_edit.html',val=res)

@obj.route('/fac_edit1',methods=['get','post'])
@login_required


def fac_edit1():
    fname = request.form['tx1']
    dtl = request.form['tx2']
    qry="UPDATE `facilities` SET `facility`=%s ,`des`=%s WHERE `id`=%s"
    val=(fname,dtl)
    iud(qry,val)
    return '''<script>alert("Edited successfully");window.location="/facview"</script>'''



@obj.route('/fac_delete',methods=['get','post'])
@login_required
def fac_delete():
    id=request.args.get('id')
    qry="DELETE FROM `facilities` WHERE `id`=%s "
    iud(qry,id)
    return '''<script>alert("Deleted successfully");window.location="/facview"</script>'''




# ////////////////////USER/////////////////////////////////////


@obj.route('/user_homepage',methods=['post','get'])
@login_required

def user_homepage():
    return render_template('user_homepage.html')

@obj.route('/reg_index',methods=['post','get'])
def reg_index():
    qry="SELECT * FROM `course`"
    res=selectall(qry)
    return render_template('reg_index.html',val=res)


@obj.route('/reg_index1',methods=['post','get'])
def reg_index1():
    fname = request.form['tx1']
    lname = request.form['tx2']
    place = request.form['tx3']
    post = request.form['tx4']
    phone = request.form['tx6']
    email = request.form['tx7']
    crs = request.form['Region']
    sem = request.form['sem']

    regno = request.form['tx11']



    username = request.form['tx8']
    password = request.form['tx9']
    qry3="SELECT * FROM `registration_no` WHERE `no`=%s"
    val3=(regno)
    res3=selectone(qry3,val3)
    if res3 is None:
        return '''<script>alert("invalid register number");window.location="/reg_index"</script>'''
    else:
        qry4="SELECT * FROM `user` WHERE `Register_no`=%s"
        val4=(regno)
        res4=selectone(qry4,val4)
        if res4 is None:
            qry="INSERT INTO `login` VALUES(NULL,%s,%s,'user')"
            val=(username,password)
            id=iud(qry,val)
            qry1="INSERT INTO `user` VALUES(NULL,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            val1=(str(id),crs,fname,lname,place,post,email,phone,regno,sem)
            iud(qry1,val1)
            return '''<script>alert("Added successfully");window.location="/"</script>'''
        else:
            return '''<script>alert("Someone already registered using this number,please check again");window.location="/reg_index"</script>'''

















@obj.route('/chatbot',methods=['post','get'])

def chatbot():
    print(session['lid'])
    q="SELECT `fname`,`lname` FROM `user` WHERE `lid`=%s"
    r=selectone(q,session['lid'])
    session['name']="Hi "+r['fname']+" "+r['lname']+". How can i help you."

    iud("DELETE FROM `chatbot` WHERE `uid`=%s",session['lid'])
    return render_template('chat2.html')


@obj.route('/insertchatbot',methods=['post'])
def insertchatbot():
    qns = request.form['textarea']
    print(qns)
    # lid = request.form['lid']
    # print(lid)

    res = cb(qns)
    if res=="tt":
        q="SELECT `timetable` FROM `timetable` WHERE `course` IN (SELECT `cid` FROM `user` WHERE `lid`=%s) AND `sem` IN(SELECT `sem` FROM `user` WHERE `lid`=%s)"
        res=selectone(q,(session['lid'],session['lid']))
        if res is not None:
            qry = "INSERT INTO `chatbot` VALUES(NULL,%s,%s,%s,curdate(),'p')"
            val = (qns, session['lid'], res['timetable'])
            iud(qry, val)
        else:
            qry = "INSERT INTO `chatbot` VALUES(NULL,%s,%s,%s,curdate(),'t')"
            val = (qns, session['lid'], "not available")
            iud(qry, val)
    elif res=="regno":
        r=selectone("SELECT `Register_no` FROM `user` WHERE `lid`=%s",session['lid'])
        qry = "INSERT INTO `chatbot` VALUES(NULL,%s,%s,%s,curdate(),'t')"
        val = (qns, session['lid'], r['Register_no'])
        iud(qry, val)
    elif res=='noti':
        q="select date,notification from notification order by id desc limit 2"
        re=selectall(q)

        if len(re)>0:
            ans=""
            for i in re:
                ans+=i['date'] + " " + str(i['notification'])+"\n"

            qry = "INSERT INTO `chatbot` VALUES(NULL,%s,%s,%s,curdate(),'t')"
            val = (qns, session['lid'], ans)
            iud(qry, val)
        else:
            qry = "INSERT INTO `chatbot` VALUES(NULL,%s,%s,%s,curdate(),'t')"
            val = (qns, session['lid'], "No notification")
            iud(qry, val)
    elif res=='mark':
        qr="SELECT `subject`.`subject`,`mark`.`mark` FROM `mark` JOIN `subject` ON `subject`.`id`=`mark`.`sub_id` WHERE `mark`.`sid`=%s"
        va=(session['lid'])
        re=selectall2(qr,va)
        if len(re)>0:
            ans=""
            for i in re:
                ans+=i['subject'] + " " + str(i['mark'])+"\n"

            qry = "INSERT INTO `chatbot` VALUES(NULL,%s,%s,%s,curdate(),'m')"
            val = (qns, session['lid'], ans)
            iud(qry, val)
        else:
            qry = "INSERT INTO `chatbot` VALUES(NULL,%s,%s,%s,curdate(),'t')"
            val = (qns, session['lid'], "not available")
            iud(qry, val)


    else:
        rr=res.split(":-")[0]

        if rr=="link":
            r2 = res.split(":-")[1]
            r=selectone("SELECT `link` FROM `locations` WHERE `place`=%s",r2)

            qry = "INSERT INTO `chatbot` VALUES(NULL,%s,%s,%s,curdate(),'l')"
            val = (qns, session['lid'], r['link'])
            iud(qry, val)

        else:

            qry = "INSERT INTO `chatbot` VALUES(NULL,%s,%s,%s,curdate(),'t')"
            val=(qns,session['lid'],res)
            iud(qry,val)
    return redirect('/response')


@obj.route('/response')
def response():


    qry = "SELECT questions,uid,answer,type FROM `chatbot` WHERE `uid`=%s"
    # val=(session['lid'])
    s = selectall2(qry,session['lid'] )
    for i in s:
        if i['type']=="m":
            i['answer']=i['answer'].split("\n")
    print(s,"kkkkkkkkkkkkkkkkk")
    print(session['lid'])
    return render_template("chat2.html",data=s,fr=session['lid'])






@obj.route('/view_time_table', methods=['get', 'post'])
@login_required

def view_time_table():
    qry1 = "SELECT * FROM `course` "
    res1 = selectall(qry1)

    return render_template('view_time_table.html',val1=res1)

@obj.route('/view_time_table1', methods=['get', 'post'])
@login_required

def view_time_table1():
    course=request.form['select']
    qry1 = "SELECT * FROM `course` "
    res1 = selectall(qry1)
    qry="SELECT * FROM `timetable` JOIN `course` ON `course`.`cid`=`timetable`.course where timetable.course=%s"
    res=selectall2(qry,course)
    return render_template('view_time_table.html',val=res,val1=res1)



@obj.route('/timetable', methods=['get', 'post'])
@login_required
def timetable():
    qry="SELECT * FROM `course` "
    res=selectall(qry)
    print(res,"JJJJJJJJJJJJJJJJJJ")
    return render_template('timetable.html',val=res)



@obj.route('/timetable1', methods=['get', 'post'])
@login_required

def timetable1():
    c = request.form['select']
    sem = request.form['select2']

    img = request.files['filefield']
    fname = secure_filename(img.filename)
    img.save(os.path.join('static/timetable', fname))

    qry="INSERT INTO `timetable` VALUES(NULL,%s,%s,%s)"
    val=(c,sem,fname)
    iud(qry,val)
    return '''<script>alert("Added");window.location='/view_time_table'</script>'''


@obj.route('/delete_timetable',methods=['get','post'])
@login_required

def delete_timetable():
    id=request.args.get('id')
    qry="DELETE FROM `timetable` WHERE `id`=%s"
    iud(qry,id)
    return '''<script>alert("deleted successfully");window.location="/view_time_table"</script>'''





@obj.route('/sub_view', methods=['get', 'post'])
@login_required

def sub_view():
    id=request.args.get('id')
    session['cur_id']=id

    qry="SELECT * FROM `subject` WHERE `cid`=%s "
    res=selectall2(qry,id)
    print(res,"JJJJJJJJJJJJJJJJJJ")
    return render_template('sub_view.html',val=res)


@obj.route('/sub_add', methods=['get', 'post'])
@login_required

def sub_add():

    return render_template('sub_add.html')


@obj.route('/sub_add1', methods=['get', 'post'])
@login_required

def sub_add1():
    sub = request.form['sub']

    qry="INSERT INTO `subject` VALUES(NULL,%s,%s,curdate())"
    val=(session['cur_id'],sub)
    iud(qry,val)
    return '''<script>alert("Added successfully");window.location="/Courseview"</script>'''


@obj.route('/delete_sub',methods=['get','post'])
@login_required

def delete_sub():
    id=request.args.get('id')
    qry="DELETE FROM `subject` WHERE `id`=%s"
    iud(qry,id)
    return '''<script>alert("Deleted successfully");window.location="/Courseview"</script>'''




@obj.route('/view_mark', methods=['get', 'post'])
@login_required

def view_mark():
    qry1="SELECT* FROM `course` "
    res1=selectall(qry1)


    return render_template('view_mark.html',val1=res1)

@obj.route('/view_mark1', methods=['get', 'post'])
@login_required

def view_mark1():
    qry1 = "SELECT* FROM `course` "
    res1 = selectall(qry1)


    course=request.form['select']
    session['course']=course
    sem=request.form['select2']
    qry="SELECT * FROM  `user` WHERE `cid`=%s AND `sem`=%s"
    val=(course,sem)
    res=selectall2(qry,val)

    return render_template('view_mark.html',val=res,val1=res1)





@obj.route('/View_mark', methods=['get', 'post'])
@login_required

def View_mark():
    id=request.args.get('id')
    session['Stu_id']=id
    qry1="SELECT * FROM `mark` JOIN `subject` ON `mark`.`sub_id`=`subject`.`id` WHERE `mark`.`sid`=%s"
    res1=selectall2(qry1,id)
    print(res1,"JJJJJJJJJJJJJJJJJJJJJ")


    return render_template('Mark_view.html',val1=res1)


#


@obj.route('/delete_mark',methods=['get','post'])
@login_required

def delete_mark():
    id=request.args.get('id')
    qry="DELETE FROM `mark` WHERE `id`=%s"
    iud(qry,id)
    return '''<script>alert("Deleted successfully");window.location="/view_mark"</script>'''


@obj.route('/mark_add', methods=['get', 'post'])
@login_required

def mark_add():
    qry1="SELECT * FROM `subject` WHERE `cid`=%s"
    res1=selectall2(qry1,session['course'])


    return render_template('mark_add.html',val1=res1)


@obj.route('/mark_add1', methods=['get', 'post'])
@login_required
def mark_add1():
    sub=request.form['sub']
    mark=request.form['mark']
    qry="INSERT INTO `mark` VALUES(NULL,%s,%s,%s)"
    val=(session['Stu_id'],sub,mark)
    iud(qry,val)
    return '''<script>alert("Added successfully");window.location="/view_mark"</script>'''


@obj.route('/notification', methods=['get', 'post'])
@login_required

def notification():
    qry1="SELECT * FROM `notification` "
    res1=selectall(qry1)


    return render_template('notification.html',val1=res1)



@obj.route('/ADD_NOTI', methods=['get', 'post'])
@login_required

def ADD_NOTI():

    return render_template('noti_add.html')


@obj.route('/ADD_NOTI1', methods=['get', 'post'])
@login_required
def ADD_NOTI1():
    noti=request.form['noti']
    qry="INSERT INTO `notification` VALUES(NULL,%s,curdate())"
    iud(qry,noti)
    return '''<script>alert("Added successfully");window.location="/notification"</script>'''


@obj.route('/delete_noti',methods=['get','post'])
@login_required

def delete_noti():
    id=request.args.get('id')
    qry="DELETE FROM `notification` WHERE `id`=%s"
    iud(qry,id)
    return '''<script>alert("Deleted successfully");window.location="/notification"</script>'''


obj.run(debug=True)